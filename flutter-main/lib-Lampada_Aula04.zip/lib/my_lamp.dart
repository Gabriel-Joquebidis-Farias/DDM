
import 'package:flutter/material.dart';


class MyLamp extends StatefulWidget {
  const MyLamp({super.key});

  @override
  State<MyLamp> createState() => _MyLampState();
}

class _MyLampState extends State<MyLamp> {
  @override
   String linkImagem ="https://i.stack.imgur.com/b983w.jpg";
   String mensagem = "Desligada";
  Widget build(BuildContext context) {
    return  Scaffold(
        body: Center(
          child: Column(
            children: [
                Image.network(linkImagem),
                Text(mensagem),
                ElevatedButton(onPressed:(){
                    mudarEstado();
                    setState(() {
                      
                    });

                },
                child: Text("Mudar Estado"))
            ],
          )
       
        ),
    );
 }
void mudarEstado(){
  if (mensagem  =="Desligado")
  {
    mensagem = "Ligado";
    linkImagem ="https://i.stack.imgur.com/ybxlO.jpg";
  }
  else {
    mensagem = "Desligado";
    linkImagem ="https://i.stack.imgur.com/b983w.jpg";
    
  }
}
}
